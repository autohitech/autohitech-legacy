Description, ,
ScanTime, 1,
Data, DWORD, id, 1,
Data, char, buf, 100,
Data, char, ID_BUF, 3,
Data, int, ID, 1,
Data, DWORD, pos, 1,
Programm,
id = @SQLConnect("data", "", "");
@sprintf(buf,"LPCU_ID='%s'", $BINDLIST_LPCU_ID);
//@SQLLast(id);
//pos=@SQLGetPos(id);
//@SQLFirst(id);
//@SQLSelect(id, "ValueTable", "BindListValue", "", "");
@SQLDelete(id, "LPCU", "");
@SQLDisconnect(id);
//�Ƴ��α� ���徲��
@EditBoxGetText("EditBox_LPCUID",ID_BUF, 3);
ID = @atoi(ID_BUF);
$AO_LPCU_ID_ALLDEL.station = ID;
$AO_LPCU_ID_ALLDEL = 0;

