Description, ,
ScanTime, 1,
Programm,
@LoadModule("PER_CONTROL_BY_LUX.mod");
