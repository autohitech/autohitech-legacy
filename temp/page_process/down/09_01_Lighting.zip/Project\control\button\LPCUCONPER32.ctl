Description, ,
ScanTime, 1,
Programm,
//PORT = 0
if (@ComboBoxGetCurSel("ComboBox_LPCUGROUPGATEWAY") == 0) {
   $AO_LPCU_CONTROL.port = 0;
}
//PORT = 1
if (@ComboBoxGetCurSel("ComboBox_LPCUGROUPGATEWAY") == 1) {
   $AO_LPCU_CONTROL.port = 1;
}
//PORT = 2
if (@ComboBoxGetCurSel("ComboBox_LPCUGROUPGATEWAY") == 2) {
   $AO_LPCU_CONTROL.port = 2;
}
//PORT = 3
if (@ComboBoxGetCurSel("ComboBox_LPCUGROUPGATEWAY") == 3) {
   $AO_LPCU_CONTROL.port = 3;
}
//PORT = 4
if (@ComboBoxGetCurSel("ComboBox_LPCUGROUPGATEWAY") == 4) {
   $AO_LPCU_CONTROL.port = 4;
}
//PORT = 5
if (@ComboBoxGetCurSel("ComboBox_LPCUGROUPGATEWAY") == 5) {
   $AO_LPCU_CONTROL.port = 5;
}
//PORT = 6
if (@ComboBoxGetCurSel("ComboBox_LPCUGROUPGATEWAY") == 6) {
   $AO_LPCU_CONTROL.port = 6;
}
      if ((@CheckBoxGetCheck("L32O1") == 1) && (@CheckBoxGetCheck("L32O2") == 1)) {
         $AO_LPCU_CONTROL.station = 01;
         $AO_LPCU_CONTROL.address = 0;
         $AO_LPCU_CONTROL.extra2 = 0;
         $AO_LPCU_CONTROL = 1;
      }
      if ((@CheckBoxGetCheck("L32O1") == 0) && (@CheckBoxGetCheck("L32O2") == 0)) {
         $AO_LPCU_CONTROL.station = 01;
         $AO_LPCU_CONTROL.address = 0;
         $AO_LPCU_CONTROL.extra2 = 1;
         $AO_LPCU_CONTROL = 0;
      }
      if ((@CheckBoxGetCheck("L32O1") == 1) && (@CheckBoxGetCheck("L32O2") == 0)) {
         $AO_LPCU_CONTROL.station = 01;
         $AO_LPCU_CONTROL.address = 1;
         $AO_LPCU_CONTROL.extra2 = 1;
         $AO_LPCU_CONTROL = 1;
      }
      if ((@CheckBoxGetCheck("L32O1") == 0) && (@CheckBoxGetCheck("L32O2") == 1)) {
         $AO_LPCU_CONTROL.station = 01;
         $AO_LPCU_CONTROL.address = 2;
         $AO_LPCU_CONTROL.extra2 = 1;
         $AO_LPCU_CONTROL = 1;
      }
   
