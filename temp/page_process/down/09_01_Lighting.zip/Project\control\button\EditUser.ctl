Description, ,
ScanTime, 1,
Data, DWORD, id, 1,
Data, BYTE, buf, 100,
Data, int, retn, 1,
Programm,
@EditBoxGetText("EditBox1",$USER_ID, 100);
@EditBoxGetText("EditBox2",$USER_PW, 100);
@EditBoxGetText("EditBox3",$USER_NAME, 100);
@EditBoxGetText("EditBox4",$USER_PART, 100);
@EditBoxGetText("EditBox5",$USER_PHONE, 100);
$ACCESS_01=@CheckBoxGetCheck("CheckBox2");
$ACCESS_02=@CheckBoxGetCheck("CheckBox3");
$ACCESS_03=@CheckBoxGetCheck("CheckBox4");
$ACCESS_04=@CheckBoxGetCheck("CheckBox5");

retn = @MessageBox("����� ������ ���� �մϴ�.\n������ �ұ��.", "���� Ȯ��", MB_YESNOCANCEL);

if(retn != IDYES) return;


id = @SQLConnect("data","","");
@sprintf(buf,"ID=%d", $ID);
@SQLUpdate(id, "USERMANAGE","USERMANAGE",buf);
@SQLDisconnect(id);

@DatabaseSetFilter ("USERMANAGE","","");
