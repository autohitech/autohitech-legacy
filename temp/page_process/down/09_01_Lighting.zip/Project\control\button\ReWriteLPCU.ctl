Description, ,
ScanTime, 1,
Programm,
@EditBoxSetText("EditBox_LPCUID","");
@EditBoxSetText("EditBox_LOCALID","");
@EditBoxSetText("EditBox_LAMP1Q","");
@EditBoxSetText("EditBox_LAMP2Q","");
@EditBoxSetText("EditBox_DESCRIPTION","");
@ComboBoxSetCurSel("ComboBox_GATEWAY", 0);
@ComboBoxSetCurSel("ComboBox_LAMPTYPE", 0);
@ComboBoxSetCurSel("ComboBox_1OR2LAMP", 0);
