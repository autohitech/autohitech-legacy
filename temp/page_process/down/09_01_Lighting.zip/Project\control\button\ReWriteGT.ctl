Description, ,
ScanTime, 1,
Programm,
@EditBoxSetText("GATEWAYIP","");
@EditBoxSetText("LMCUDES","");
@EditBoxSetText("LOCALID","");
@ComboBoxSetCurSel("cmbUSE", 0);
@ComboBoxSetCurSel("cmbUCons", 0);

