Description, ,
ScanTime, 1,
Programm,
@LoadModule("LPCU_Schedule.mod");
