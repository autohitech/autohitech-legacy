Description, ,
ScanTime, 1,
Programm,
@EditBoxSetText("ID","");
@EditBoxSetText("PASSWORD","");
@EditBoxSetText("NAME","");
@EditBoxSetText("PHONE","");
@EditBoxSetText("PART","");
@EditBoxSetText("ACCESS","");
@EditBoxSetText("USE","");

