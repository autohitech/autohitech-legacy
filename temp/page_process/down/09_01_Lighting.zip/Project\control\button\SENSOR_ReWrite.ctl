Description, ,
ScanTime, 1,
Programm,
@EditBoxSetText("SENSOR_ELTD","");
@EditBoxSetText("SENSOR_DESCRIPTION","");
@CheckBoxSetCheck("SENSOR_USE", 0);
@ComboBoxSetCurSel("SENSOR_GATEWAY", 0);

