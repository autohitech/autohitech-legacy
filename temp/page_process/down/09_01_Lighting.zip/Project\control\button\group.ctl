Description, ,
ScanTime, 1,
Programm,
@LoadModule("LPCUGROUP.mod");
