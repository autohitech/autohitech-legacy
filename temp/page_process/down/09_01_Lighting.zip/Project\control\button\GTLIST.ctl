Description, ,
ScanTime, 1,
Programm,
@LoadModule("GatewayList.MOD")
