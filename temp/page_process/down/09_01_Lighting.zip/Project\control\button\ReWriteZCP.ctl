Description, ,
ScanTime, 1,
Programm,
@EditBoxSetText("EditBox_ZCTID","");
@EditBoxSetText("EditBox_ZCTSPGWID","");
@EditBoxSetText("EditBox_AREA","");
@EditBoxSetText("EditBox_ZCTDES","");
@ComboBoxSetCurSel("ComboBox_ZCTGATEWAY", 0);
@CheckBoxSetCheck("CheckBox_ZCTUCONSTRUC", 0);
