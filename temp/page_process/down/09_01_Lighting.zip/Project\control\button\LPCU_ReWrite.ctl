Description, ,
ScanTime, 1,
Programm,
@EditBoxSetText("EditBox_LAMP1Q","");
@EditBoxSetText("EditBox_LAMP2Q","");
@EditBoxSetText("EditBox_DESCRIPTION","");
@EditBoxSetText("EditBox_LPCUID","");
@EditBoxSetText("EditBox_LOCALID","");
@CheckBoxSetCheck("CheckBox_CONS", 0);
@ComboBoxSetCurSel("ComboBox_GATEWAY", 0);
@ComboBoxSetCurSel("ComboBox_TYPE", 0);
