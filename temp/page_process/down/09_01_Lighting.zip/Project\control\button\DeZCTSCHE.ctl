Description, ,
ScanTime, 1,
Data, char, buf, 100,
Data, int, tmp, 1,
Data, DWORD, id, 1,
Data, int, retnmb, 1,
Data, char, time, 10,
Programm,

retnmb = @MessageBox("�����͸� ���� �մϴ�.\n�����͸� ���� �Ͻðڽ��ϱ�?", "�۾� Ȯ��", MB_YESNOCANCEL);

if(retnmb != IDYES) return;

//�����ͺ��̽� �߰� �κ�
id = @SQLConnect("data","","");
tmp = @atoi($BINDLIST_ZCTSCHE_INDEX);
@sprintf(buf, "N1 = %d", tmp);
@SQLDelete(id, "ZCT_SCHEDULE", buf);
@SQLDisconnect(id);
@DatabaseSetFilter("DB_ZCT_SCHEDULE","","");

//�Ƴ��α� ���徲��
//�ð��� �޴� �κ�
@sprintf(time, "%02d%02d", @atoi($BINDLIST_ZCTSCHE_HOUR),@atoi($BINDLIST_ZCTSCHE_MIN));

if (@ComboBoxGetCurSel("ZCT_SCHE_LMCUID") == 0){
  $AO_ZCT_SCHEDULE.port = 6;
  if (@atoi($BINDLIST_ZCTSCHE_PGWID) == 0101){
    $AO_ZCT_SCHEDULE.station = 257;
  }elseif(@atoi($BINDLIST_ZCTSCHE_PGWID) == 0102){
    $AO_ZCT_SCHEDULE.station = 258;
  }elseif(@atoi($BINDLIST_ZCTSCHE_PGWID) == 0103){
    $AO_ZCT_SCHEDULE.station = 259;
  }elseif(@atoi($BINDLIST_ZCTSCHE_PGWID) == 0104){
    $AO_ZCT_SCHEDULE.station = 260;
  }elseif(@atoi($BINDLIST_ZCTSCHE_PGWID) == 0105){
    $AO_ZCT_SCHEDULE.station = 261;
  }
}elseif(@ComboBoxGetCurSel("ZCT_SCHE_LMCUID") == 1){
  $AO_ZCT_SCHEDULE.port = 7;
  if (@atoi($BINDLIST_ZCTSCHE_PGWID) == 0201){
    $AO_ZCT_SCHEDULE.station = 513;
  }elseif(@atoi($BINDLIST_ZCTSCHE_PGWID) == 0202){
    $AO_ZCT_SCHEDULE.station = 514;
  }elseif(@atoi($BINDLIST_ZCTSCHE_PGWID) == 0203){
    $AO_ZCT_SCHEDULE.station = 515;
  }elseif(@atoi($BINDLIST_ZCTSCHE_PGWID) == 0204){
    $AO_ZCT_SCHEDULE.station = 516;
  }elseif(@atoi($BINDLIST_ZCTSCHE_PGWID) == 0205){
    $AO_ZCT_SCHEDULE.station = 517;
  }elseif(@atoi($BINDLIST_ZCTSCHE_PGWID) == 0206){
    $AO_ZCT_SCHEDULE.station = 518;
  }
}elseif(@ComboBoxGetCurSel("ZCT_SCHE_LMCUID") == 2){
  $AO_ZCT_SCHEDULE.port = 8;
}

$AO_ZCT_SCHEDULE = @atoi(time);

