Description, ,
ScanTime, 1,
Data, DWORD, id, 1,
Data, char, time, 10,
Data, char, buf, 13,
Data, int, retnmb, 1,
Data, char, val, 100,
Data, char, tmp, 100,
Programm,
retnmb = @MessageBox("�����͸� ���� �մϴ�.\n�����͸� ���� �Ͻðڽ��ϱ�?", "�۾� Ȯ��", MB_YESNOCANCEL);

if(retnmb != IDYES) return;





id = @SQLConnect("data","","");
tmp = $BINDLIST_SCHEDULE_LMCUID;
@sprintf(buf, "LMCUID = %s", tmp);
@SQLDelete(id, "LPCU_SCHEDULE_SET_INFO", buf);
@SQLDisconnect(id);
@DatabaseSetFilter("DB_LPCUSCHEDULE","","");

//@sprintf(val, "%02d%02d", @atoi($BINDLIST_SCHEDULE_HOUR),@atoi($BINDLIST_SCHEDULE_MIN));
if (@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 0){
  $AO_LPCU_SCHEDULE_ALLDEL.port = 0;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 1){
  $AO_LPCU_SCHEDULE_ALLDEL.port = 1;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 2){
  $AO_LPCU_SCHEDULE_ALLDEL.port = 2;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 3){
  $AO_LPCU_SCHEDULE_ALLDEL.port = 3;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 4){
  $AO_LPCU_SCHEDULE_ALLDEL.port = 4;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 5){
  $AO_LPCU_SCHEDULE_ALLDEL.port = 5;
}
$AO_LPCU_SCHEDULE_ALLDEL.value = 1;
