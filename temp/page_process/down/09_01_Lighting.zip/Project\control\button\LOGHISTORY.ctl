Description, ,
ScanTime, 1,
Programm,
@LoadModule("LOGHISTORY.mod");
