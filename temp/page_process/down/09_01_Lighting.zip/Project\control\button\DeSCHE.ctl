Description, ,
ScanTime, 1,
Data, DWORD, id, 1,
Data, int, tmp, 1,
Data, char, buf, 100,
Data, int, retnmb, 1,
Data, char, time, 10,
Programm,
retnmb = @MessageBox("�����͸� ���� �մϴ�.\n�����͸� ���� �Ͻðڽ��ϱ�?", "�۾� Ȯ��", MB_YESNOCANCEL);

if(retnmb != IDYES) return;





id = @SQLConnect("data","","");
tmp = @atoi($BINDLIST_SCHEDULE_INDEX);
@sprintf(buf, "N1 = %d", tmp);
@SQLDelete(id, "LPCU_SCHEDULE_SET_INFO", buf);
@SQLDisconnect(id);
@DatabaseSetFilter("DB_LPCUSCHEDULE","","");

@sprintf(time, "%02d%02d", @atoi($BINDLIST_SCHEDULE_HOUR),@atoi($BINDLIST_SCHEDULE_MIN));

if (@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 0){
  $AO_LPCU_SCHEDULE_DEL.port = 0;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 1){
  $AO_LPCU_SCHEDULE_DEL.port = 1;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 2){
  $AO_LPCU_SCHEDULE_DEL.port = 2;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 3){
  $AO_LPCU_SCHEDULE_DEL.port = 3;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 4){
  $AO_LPCU_SCHEDULE_DEL.port = 4;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 5){
  $AO_LPCU_SCHEDULE_DEL.port = 5;
}

$AO_LPCU_SCHEDULE_DEL = @atoi(time);
