Description, ,
ScanTime, 1,
Data, char, ID_BUF, 3,
Data, int, ID, 1,
Data, char, LAMP1_CAP, 10,
Data, char, LAMP2_CAP, 100,
Data, int, LAMP1, 1,
Data, int, LAMP2, 1,
Data, int, pos, 1,
Programm,
@EditBoxGetText("EditBox1",ID_BUF, 3);
ID = @atoi(ID_BUF);

@EditBoxGetText("EditBox2",LAMP1_CAP, 5);
LAMP1 = @atoi(LAMP1_CAP);

@EditBoxGetText("EditBox3",LAMP2_CAP, 5);
LAMP2 = @atoi(LAMP2_CAP);

pos = @RadioButtonGetPos("Radio1");

if (pos == 0) {
$AO_LPCU_ID.station = ID;
$AO_LPCU_ID.Extra2 = LAMP1;
$AO_LPCU_ID = 0;
}

pos = @RadioButtonGetPos("Radio1");

if (pos == 1) {
$AO_LPCU_ID.station = ID;
$AO_LPCU_ID.Extra2 = LAMP1+LAMP2;
$AO_LPCU_ID = 8;
}
