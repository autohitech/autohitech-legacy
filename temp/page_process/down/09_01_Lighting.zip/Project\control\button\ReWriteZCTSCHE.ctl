Description, ,
ScanTime, 1,
Programm,
@EditBoxSetText("ZCT_SCHE_PGWID","");

