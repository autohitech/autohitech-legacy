Description, ,
ScanTime, 1,
Programm,
@LoadModule("ZCTSCHEDULE.MOD");
