Description, ,
ScanTime, 1,
Data, DWORD, id, 1,
Data, BYTE, buf, 100,
Data, char, ID_BUF, 3,
Data, char, LAMP1_CAP, 10,
Data, char, LAMP2_CAP, 100,
Data, int, ID, 1,
Data, int, LAMP1, 1,
Data, int, LAMP2, 1,
Data, int, pos, 1,
Data, int, con, 1,
Data, int, tmp, 1,
Data, int, retnmb, 1,
Programm,
retnmb = @MessageBox("�����͸� ���� �մϴ�.\n���ο� �����ͷ� ���� �Ͻðڽ��ϱ�?", "�۾� Ȯ��", MB_YESNOCANCEL);

if(retnmb != IDYES) return;



id = @SQLConnect("data","","");
tmp = @atoi($BINDLIST_LPCU_INDEX);
@sprintf(buf,"N1 = %d", tmp);
@SQLUpdate(id, "LPCU","LPCU",buf);
@SQLDisconnect(id);
@DatabaseSetFilter("DB_LPCU","","");
//�Ƴ��α� ���徲��
@EditBoxGetText("EditBox_LPCUID",ID_BUF, 3);
ID = @atoi(ID_BUF);

@EditBoxGetText("EditBox_LAMP1Q",LAMP1_CAP, 5);
LAMP1 = @atoi(LAMP1_CAP);

@EditBoxGetText("EditBox_LAMP2Q",LAMP2_CAP, 5);
LAMP2 = @atoi(LAMP2_CAP);

pos = @RadioButtonGetPos("Radio_LAMP");

if (pos == 0) {
$AO_LPCU_ID.station = ID;
$AO_LPCU_ID.Extra2 = LAMP1;
$AO_LPCU_ID = 0;
}

pos = @RadioButtonGetPos("Radio_LAMP");

if (pos == 1) {
$AO_LPCU_ID.station = ID;
$AO_LPCU_ID.Extra2 = LAMP1+LAMP2;
$AO_LPCU_ID = 8;
}

