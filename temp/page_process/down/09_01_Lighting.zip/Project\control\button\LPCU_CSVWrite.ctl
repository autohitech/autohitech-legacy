Description, ,
ScanTime, 1,
Data, int, id, 1,
Data, int, i, 1,
Data, char, buf, 100,
Data, char, filename, 100,
Data, char, ExcelPath, 100,
Programm,
@CsvBlockFree(id);
id = @CsvBlockNew(4,159);
   @SetTagValue("BINDLIST_LPCU_SET1", "1,2���");
   @SetTagValue("BINDLIST_LPCU_SET2", "�� ����");
   @SetTagValue("BINDLIST_LPCU_SET3", "1��� �뷮");
   @SetTagValue("BINDLIST_LPCU_SET4", "2��� �뷮");
@CsvBlockGet(id, "CSV.txt", 0);
for (i = 1; i < 159; i = i + 1)
{
   $LPCU_SET_L.address = $LPCU_SET_L.address + 1;
if ($LPCU_SET_L == 128)
{
   @SetTagValue("BINDLIST_LPCU_SET1", "2���");
   @SetTagValue("BINDLIST_LPCU_SET2", "��Ʈ����");
   $M_LPCU_SET_LM1_Q = $LPCU_SET_LM1_Q;
   $M_LPCU_SET_LM2_Q = $LPCU_SET_LM2_Q;  
}
elseif ($LPCU_SET_L > 128)
{
   @SetTagValue("BINDLIST_LPCU_SET1", "2���");
   @SetTagValue("BINDLIST_LPCU_SET2", "��Ż��");
   $M_LPCU_SET_LM1_Q = $LPCU_SET_LM1_Q;
   $M_LPCU_SET_LM2_Q = $LPCU_SET_LM2_Q;  
}
elseif ($LPCU_SET_L < 128 && $LPCU_SET_L >0)
{
   @SetTagValue("BINDLIST_LPCU_SET1", "1���");
   @SetTagValue("BINDLIST_LPCU_SET2", "��Ż��");
   $M_LPCU_SET_LM1_Q = $LPCU_SET_LM1_Q;
   $M_LPCU_SET_LM2_Q = $LPCU_SET_LM2_Q;   
}
elseif ($LPCU_SET_L == 0)
{
   @SetTagValue("BINDLIST_LPCU_SET1", "1���");
   @SetTagValue("BINDLIST_LPCU_SET2", "��Ʈ����");
   $M_LPCU_SET_LM1_Q = $LPCU_SET_LM1_Q;
   $M_LPCU_SET_LM2_Q = $LPCU_SET_LM2_Q;  
}

   $LPCU_SET_LM1_Q.address = $LPCU_SET_LM1_Q.address + 1;
   $LPCU_SET_LM2_Q.address = $LPCU_SET_LM2_Q.address + 1;

@CsvBlockGet(id, "CSV1.txt", i);
//@CsvBlockSet(id, "CSV", i);
}
@sprintf(buf, "C:\\LPCU_Info_%4d%02d%02d%02d%02d%02d.csv", @GetDateYear(),@GetDateMon(),@GetDateDay(),@GetTimeHour(),@GetTimeMin(),@GetTimeSec());
@SetTagValue("filename", buf);
@CsvBlockSave(id, $filename);
$LPCU_SET_L.address = 220;
$LPCU_SET_LM1_Q.address = 221;
$LPCU_SET_LM2_Q.address = 222; 
@sprintf(ExcelPath, "D:\\Microsoft Office\\OFFICE11\\EXCEL.exe C:\\LPCU_Info_%4d%02d%02d%02d%02d%02d.csv", @GetDateYear(),@GetDateMon(),@GetDateDay(),@GetTimeHour(),@GetTimeMin(),@GetTimeSec());
 
//@ExcelReportPrepare(buf,"", , , ,,,);
@WinExec(ExcelPath);
//@WinExec("D:\\Micro Soft\\OFFICE11\\EXCEL.EXE buf");
