Description, ,
ScanTime, 1,
Programm,
@MenuMessage("EXIT");
