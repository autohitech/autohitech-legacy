Description, ,
ScanTime, 1,
Data, DWORD, id, 1,
Programm,
id = @SQLConnect("data","","");
@SQLInsert(id, "LPCU","LPCU");
@SQLDisconnect(id);
