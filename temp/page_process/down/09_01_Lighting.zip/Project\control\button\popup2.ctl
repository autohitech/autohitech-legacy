Description, ,
ScanTime, 1,
Programm,
@FileCopy("C:\\testwork\\�÷���\\graphic\\popup2.mod","C:\\testwork\\�÷���\\graphic\\a.mod", 0);
@ModuleCloseName("popup.mod");
//@LoadModule("popup.mod");
