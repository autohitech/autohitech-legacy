Description, ,
ScanTime, 1,
Data, DWORD, id, 1,
Data, char, lux, 100,
Data, int, tmp, 1,
Data, char, buf, 100,
Data, int, retnmb, 1,
Programm,

retnmb = @MessageBox("�����͸� ���� �մϴ�.\n���ο� �����ͷ� ���� �Ͻðڽ��ϱ�?", "�۾� Ȯ��", MB_YESNOCANCEL);

if(retnmb != IDYES) return;


//�����ͺ��̽� �߰� �κ�
id = @SQLConnect("data","","");
tmp = @atoi($BINDLIST_LUXG_INDEX);
@sprintf(buf, "N1 = %d", tmp);
@SQLUpdate(id, "LUXSENSORG", "LUXSENSORG", buf);
@SQLDisconnect(id);
@DatabaseSetFilter("DB_LUXGSET","","");

//�Ƴ��α� ���徲��
//������ �޴� �κ�
@sprintf(lux, "%02d%02d", @atoi($BINDLIST_LUXG_ONLUX),@atoi($BINDLIST_LUXG_OFFLUX));
//��ü �׷� ���ý�
if ($BINDLIST_LUXG_GROUPID == 0) {
   if (@CheckBoxGetCheck("LUXGSET") == 1) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 0;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 1;
   }
   if (@CheckBoxGetCheck("LUXGSET") == 0) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 0;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 0;
   }
}

//¦�� �׷� ���ý�
if ($BINDLIST_LUXG_GROUPID == 1) {
   if (@CheckBoxGetCheck("LUXGSET") == 1) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 20;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 1;
   }
   if (@CheckBoxGetCheck("LUXGSET") == 0) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 20;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 0;
   }
}

//Ȧ�� �׷� ���ý�
if ($BINDLIST_LUXG_GROUPID == 2) {
   if (@CheckBoxGetCheck("LUXGSET") == 1) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 21;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 1;
   }
   if (@CheckBoxGetCheck("LUXGSET") == 0) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 21;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 0;
   }
}

//3���� ���� �������� 0�� �׷� ���ý�
if ($BINDLIST_LUXG_GROUPID == 3) {
   if (@CheckBoxGetCheck("LUXGSET") == 1) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 30;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 1;
   }
   if (@CheckBoxGetCheck("LUXGSET") == 0) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 30;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 0;
   }
}



//3���� ���� �������� 1�� �׷� ���ý�
if ($BINDLIST_LUXG_GROUPID == 4) {
   if (@CheckBoxGetCheck("LUXGSET") == 1) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 31;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 1;
   }
   if (@CheckBoxGetCheck("LUXGSET") == 0) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 31;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 0;
   }
}


//3���� ���� �������� 2�� �׷� ���ý�
if ($BINDLIST_LUXG_GROUPID == 5) {
   if (@CheckBoxGetCheck("LUXGSET") == 1) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 32;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 1;
   }
   if (@CheckBoxGetCheck("LUXGSET") == 0) {
      $AO_LUX_CONTROL_GROUP.station = 0101;
      $AO_LUX_CONTROL_GROUP.address = 32;   
      $AO_LUX_CONTROL_GROUP.Extra2 = lux;
      $AO_LUX_CONTROL_GROUP = 0;
   }
}


