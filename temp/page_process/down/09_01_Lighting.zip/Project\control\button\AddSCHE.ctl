Description, ,
ScanTime, 1,
Data, DWORD, id, 1,
Data, char, ID_BUF, 13,
Data, int, ID, 1,
Data, char, time, 10,
Data, int, retnmb, 1,
Programm,
retnmb = @MessageBox("���� ����� �մϴ�.\n���ο� �����͸� ��� �Ͻðڽ��ϱ�?", "�۾� Ȯ��", MB_YESNOCANCEL);

if(retnmb != IDYES) return;





//�����ͺ��̽� �߰� �κ�
id = @SQLConnect("data","","");
@SQLInsert(id, "LPCU_SCHEDULE_SET_INFO","SCHEDULE");
@SQLDisconnect(id);
@DatabaseSetFilter("DB_LPCUSCHEDULE","","");
//�Ƴ��α� ���徲��
//�ð��� �޴� �κ�
@sprintf(time, "%02d%02d", @atoi($BINDLIST_SCHEDULE_HOUR),@atoi($BINDLIST_SCHEDULE_MIN));

if (@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 0){
  $AO_LPCU_SCHEDULE_ADD.port = 0;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 1){
  $AO_LPCU_SCHEDULE_ADD.port = 1;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 2){
  $AO_LPCU_SCHEDULE_ADD.port = 2;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 3){
  $AO_LPCU_SCHEDULE_ADD.port = 3;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 4){
  $AO_LPCU_SCHEDULE_ADD.port = 4;
}elseif(@ComboBoxGetCurSel("ComboBox_ScheGATEWAY") == 5){
  $AO_LPCU_SCHEDULE_ADD.port = 5;
}

//��ü �׷� ���ý�
if ($BINDLIST_SCHEDULE_GROUP == 0) {
//��� ���� OFF    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 0000;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 0032;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//2������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 0004;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1,2���� ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 0036;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
}
//¦�� �׷� ���ý�
if ($BINDLIST_SCHEDULE_GROUP == 1) {
//��� ���� OFF    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 2000;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 2032;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//2������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 2004;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1,2���� ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 2036;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
}
//Ȧ�� �׷� ���ý�
if ($BINDLIST_SCHEDULE_GROUP == 2) {
//��� ���� OFF    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 2100;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 2132;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//2������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 2104;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1,2���� ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 2136;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
}
//3���� ���� �������� 0�� �׷� ���ý�
if ($BINDLIST_SCHEDULE_GROUP == 3) {
//��� ���� OFF    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3000;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3032;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//2������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3004;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1,2���� ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3036;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
}
//3���� ���� �������� 1�� �׷� ���ý�
if ($BINDLIST_SCHEDULE_GROUP == 4) {
//��� ���� OFF    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3100;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3132;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//2������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3104;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1,2���� ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3136;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
}
//3���� ���� �������� 2�� �׷� ���ý�
if ($BINDLIST_SCHEDULE_GROUP == 5) {
//��� ���� OFF    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3200;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 0))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3232;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//2������ ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 0)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3204;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
//1,2���� ON    
   if (($BINDLIST_SCHEDULE_1LAMPON == 1)&&($BINDLIST_SCHEDULE_2LAMPON == 1))  {
      $AO_LPCU_SCHEDULE_ADD.Extra2 = 3236;   
      $AO_LPCU_SCHEDULE_ADD = @atoi(time);
   }
}
