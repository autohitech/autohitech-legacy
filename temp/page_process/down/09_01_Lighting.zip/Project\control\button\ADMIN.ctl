Description, ,
ScanTime, 1,
Data, char, USER_ID, 100,
Data, char, USER_PW, 100,
Data, int, id, 1,
Data, char, WHERE_BUF, 100,
Data, int, ID_CONFIRM, 1,
Data, int, PW_CONFIRM, 1,
Programm,
//USER_ID�� USER_PW�� ����//
@EditBoxGetText("EditBox1",USER_ID, 10);
@EditBoxGetText("EditBox2",USER_PW, 10);


//����Ÿ���̽� �����Ͽ� USER Ȯ��//

id = @SQLConnect("data","","");
@sprintf($LOGIN_USER_ID,"");
@sprintf($LOGIN_USER_PW,"");
@sprintf($USER_ID,"");
@sprintf($USER_PW,"");
@sprintf($USER_NAME,"");
@sprintf($USER_PART,"");
@sprintf($USER_PHONE,"");
$ID = 0; 
$ACCESS_01 = 0; $ACCESS_02 = 0; $ACCESS_03 = 0; $ACCESS_04 = 0;
$LOGIN_ACCESS_01 = 0; $LOGIN_ACCESS_02 = 0; $LOGIN_ACCESS_03 = 0; $LOGIN_ACCESS_04 = 0;

@sprintf(WHERE_BUF,"USER_ID like '%s' AND USER_PW like '%s'",USER_ID,USER_PW);
//@sprintf($WHERE_BUF,"USER_ID like 'ADMIN' AND USER_PW like 'ADMIN'");
@SQLSelect(id,"USERMANAGE", "USERMANAGE",WHERE_BUF,"");
@SQLFirst(id);

if ($ID == 0) {
@Message("ID �Ǵ� �н����尡 �������� �ʽ��ϴ�.");
returns;
}

if ($ID >= 1) {
ID_CONFIRM = @strcmp(USER_ID,$USER_ID);
PW_CONFIRM = @strcmp(USER_PW,$USER_PW);

if (ID_CONFIRM == 0 && PW_CONFIRM == 0) {
@sprintf($LOGIN_USER_ID,"%s",$USER_ID);
@sprintf($LOGIN_USER_PW,"%s",$USER_PW);
$LOGIN_ACCESS_01 = $LOGIN_ACCESS_01; $LOGIN_ACCESS_02 = $LOGIN_ACCESS_02; 
$LOGIN_ACCESS_03 = $LOGIN_ACCESS_03; $LOGIN_ACCESS_04 = $LOGIN_ACCESS_04;
@EditBoxGetText("EditBox1",$LOGHISTORY_ID, 100);
@sprintf($LOGHISTORY_TIME,"%04d%02d%02d%02d%02d%02d",@GetDateYear(),@GetDateMon(), @GetDateDay(), @GetTimeHour(), @GetTimeMin(), @GetTimeSec());
@SetTagValue("LOGHISTORY_TYPE", "LOG_IN");
@SQLInsert(id, "LOGHISTORY", "LOGHISTORY");
@CloseModule();
@LoadModule("main.mod");
}

else {
@Message("ID �Ǵ� �н����尡 Ʋ���ϴ�.");
}

}

@SQLDisconnect(id);

