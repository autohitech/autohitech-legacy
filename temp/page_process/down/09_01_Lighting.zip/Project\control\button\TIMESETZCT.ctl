Description, ,
ScanTime, 1,
Data, int, index, 1,
Programm,
index=@ComboBoxGetCurSel("ComboBox_ZCTGATEWAY");
if (index == 0) {
   $AO_ZCT_TIMESET.port = 0;
   $AO_ZCT_TIMESET = 0;
}
if (index == 1) {
   $AO_ZCT_TIMESET.port = 1;
   $AO_ZCT_TIMESET = 0;
}
if (index == 2) {
   $AO_ZCT_TIMESET.port = 2;
   $AO_ZCT_TIMESET = 0;
}
if (index == 3) {
   $AO_ZCT_TIMESET.port = 3;
   $AO_ZCT_TIMESET = 0;
}
if (index == 4) {
   $AO_ZCT_TIMESET.port = 4;
   $AO_ZCT_TIMESET = 0;
}
if (index == 5) {
   $AO_ZCT_TIMESET.port = 5;
   $AO_ZCT_TIMESET = 0;
}
if (index == 6) {
   $AO_ZCT_TIMESET.port = 6;
   $AO_ZCT_TIMESET = 0;
}
if (index == 7) {
   $AO_ZCT_TIMESET.port = 7;
   $AO_ZCT_TIMESET = 0;
}
if (index == 8) {
   $AO_ZCT_TIMESET.port = 8;
   $AO_ZCT_TIMESET = 0;
}
if (index == 9) {
   $AO_ZCT_TIMESET.port = 9;
   $AO_ZCT_TIMESET = 0;
}
@MessageBox("��ǻ�Ϳ� ����Ʈ������ �ð��� ����ȭ �Ǿ����ϴ�.","�ð�����ȭ",MB_OK);
