Description, ,
ScanTime, 1,
Data, DWORD, id, 1,
Data, BYTE, buf, 100,
Data, BYTE, tmp, 100,
Programm,

id = @SQLConnect("data", "", "");
@sprintf(buf,"ID=%d", $ID);
@SQLDelete(id, "USERMANAGE",buf);
@SQLDisconnect(id);

@DatabaseSetFilter ("USERMANAGE","","");
