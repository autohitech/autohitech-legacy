Description, ,
ScanTime, 1,
Data, DWORD, id, 1,
Data, BYTE, buf, 100,
Programm,
id = @SQLConnect("data", "", "");
@sprintf(buf,"ID='%s'", $ID);
@SQLDelete(id, "LMCU",buf);
@SQLDisconnect(id);
