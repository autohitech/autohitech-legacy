Description, ,
ScanTime, 1,
Data, char, tmp, 100,
Data, DWORD, id, 1,
Data, char, buf, 100,
Programm,
@EditBoxGetText("UHis", tmp, 20)
@sprintf(buf, "USERNAME like '%s'", tmp); 
@DatabaseSetFilter ("LOGHISTORY",buf,"USERNAME DESC");

