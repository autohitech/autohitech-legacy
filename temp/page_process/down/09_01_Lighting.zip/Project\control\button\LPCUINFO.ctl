Description, ,
ScanTime, 1,
Programm,
@LoadModule("SLightList.MOD")
