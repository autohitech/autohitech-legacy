Description, ,
ScanTime, 1,
Programm,
@EditBoxSetText("EditBox_SCHEDULEDES","");
@ComboBoxSetCurSel("ComboBox_ScheGATEWAY", 0);
@ComboBoxSetCurSel("ComboBox_GroupID", 0);
@ComboBoxSetCurSel("ComboBox_Hour", 0);
@ComboBoxSetCurSel("ComboBox_MIN", 0);
@CheckBoxSetCheck("CheckBox_1LampON", 0);
@CheckBoxSetCheck("CheckBox_2LampON", 0);
@CheckBoxSetCheck("CheckBox_RESET", 0);
