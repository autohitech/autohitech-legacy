Description, ,
ScanTime, 1,
Programm,
@LoadModule("main.mod");
