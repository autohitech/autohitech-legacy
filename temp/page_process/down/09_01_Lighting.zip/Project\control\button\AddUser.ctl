Description, ,
ScanTime, 1,
Data, int, retn, 1,
Data, char, wherebuf, 100,
Data, DWORD, id, 1,
Data, int, retn1, 1,
Programm,
@SetTagValue("USER_IDTMP1", $USER_ID); 
@EditBoxGetText("EditBox1",$USER_ID, 100);
@EditBoxGetText("EditBox2",$USER_PW, 100);
@EditBoxGetText("EditBox3",$USER_NAME, 100);
@EditBoxGetText("EditBox4",$USER_PART, 100);
@EditBoxGetText("EditBox5",$USER_PHONE, 100);
$ACCESS_01=@CheckBoxGetCheck("CheckBox2");
$ACCESS_02=@CheckBoxGetCheck("CheckBox3");
$ACCESS_03=@CheckBoxGetCheck("CheckBox4");
$ACCESS_04=@CheckBoxGetCheck("CheckBox5");

retn = @MessageBox("���� ����� �մϴ�.\n����� �ұ��.", "�۾� Ȯ��", MB_YESNOCANCEL);

if(retn != IDYES) return;
@SetTagValue("USER_IDTMP", $USER_ID); 
@sprintf( wherebuf, "USER_ID = '%s'", $USER_IDTMP1);
id = @SQLConnect("data","","");
@SQLSelect(id, "USERMANAGE", "USERMANAGE", wherebuf, "");
@SQLFirst(id);
retn1=@stricmp($USER_ID, $USER_IDTMP);

if (retn1 == 0) {
   @MessageBox("�̹� �����ϴ� ���̵� �Դϴ�.\n���ο� ���̵� �Է��ϼ���", "�ߺ� ����",MB_OK);
   @SQLDisconnect(id);
   return;
}
@SetTagValue("USER_ID", $USER_IDTMP);
@SQLInsert(id, "USERMANAGE","USERMANAGE");
@SQLDisconnect(id);

@DatabaseSetFilter ("USERMANAGE","","");
