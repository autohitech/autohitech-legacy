Description, ,
ScanTime, 1,
Programm,
@EditBoxSetText("MOVESENSOR_ELTDID","");
@EditBoxSetText("MOVESENSOR_ZCTID","");
@CheckBoxSetCheck("MOVESENSOR_SETNUM", 0);
