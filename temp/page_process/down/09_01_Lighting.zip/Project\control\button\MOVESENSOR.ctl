Description, ,
ScanTime, 1,
Programm,
@LoadModule("MOVESENSOR.MOD");
