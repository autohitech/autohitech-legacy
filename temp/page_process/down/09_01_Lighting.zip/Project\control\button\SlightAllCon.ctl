Description, ,
ScanTime, 1,
Programm,
$LPCU_ALL_ON_OFF = ON;
