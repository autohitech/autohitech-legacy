Description, ,
ScanTime, 1,
Data, int, i, 1,
Data, char, buf, 100,
Programm,
for (i = 1; i < 54; i = i+1) { 
   @sprintf( buf, "L%dO1", i);
   @CheckBoxSetCheck(buf, 0);
}
for (i = 1; i < 54; i = i+1) { 
   @sprintf( buf, "L%dO2", i);
   @CheckBoxSetCheck(buf, 0);
}
