Description, ,
ScanTime, 1,
Programm,
@LoadModule("GROUP_CONTROL_BY_LUX.mod");
