Description, ,
ScanTime, 1,
Programm,
$AO_LPCU_SCHEDULE_ALLDEL = 0;

