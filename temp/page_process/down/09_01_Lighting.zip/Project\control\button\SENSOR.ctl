Description, ,
ScanTime, 1,
Programm,
@LoadModule("SENSORLIST.MOD");
