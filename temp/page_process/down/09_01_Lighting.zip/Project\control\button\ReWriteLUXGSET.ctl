Description, ,
ScanTime, 1,
Programm,
@EditBoxSetText("LUXGPGW","");
@EditBoxSetText("ONLUXG","");
@EditBoxSetText("OFFLUXG","");
@ComboBoxSetCurSel("ComboBox_LUXGGATEWAY", 0);
@ComboBoxSetCurSel("ComboBox_LUXG", 0);
@CheckBoxSetCheck("LUXGSET", 0);
