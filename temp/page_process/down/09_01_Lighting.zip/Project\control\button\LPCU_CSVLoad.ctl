Description, ,
ScanTime, 1,
Data, int, i, 1,
Data, int, retn, 1,
Data, int, Number, 1,
Data, DWORD, id, 1,
Data, int, is, 1,
Data, char, buf, 100,
Data, char, buf1, 100,
Data, char, buf2, 100,
Data, char, buf3, 100,
Data, int, retn1, 1,
Data, int, retn2, 1,
Programm,
id = @SQLConnect("data", "", "");
for (i = 1; i < 159; i = i + 1)
{
@CsvBlockGetText(is, 0, i, buf);
@CsvBlockGetText(is, 1, i, buf1);
@CsvBlockGetText(is, 2, i, buf2);
@CsvBlockGetText(is, 3, i, buf3);
retn1=@stricmp(buf,"2���");
retn2=@stricmp(buf,"��Ʈ����");
if ((retn1 == 0) && (retn2 == 0))
{
   @SetTagValue("BINDLIST_LPCU_SET1", "2���");
   @SetTagValue("BINDLIST_LPCU_SET2", "��Ʈ����");
   $M_LPCU_SET_LM1_Q = $LPCU_SET_LM1_Q;
   $M_LPCU_SET_LM2_Q = $LPCU_SET_LM2_Q;  
}
elseif ($LPCU_SET_L > 128)
{
   @SetTagValue("BINDLIST_LPCU_SET1", "2���");
   @SetTagValue("BINDLIST_LPCU_SET2", "��Ż��");
   $M_LPCU_SET_LM1_Q = $LPCU_SET_LM1_Q;
   $M_LPCU_SET_LM2_Q = $LPCU_SET_LM2_Q;  
}
elseif ($LPCU_SET_L < 128 && $LPCU_SET_L >0)
{
   @SetTagValue("BINDLIST_LPCU_SET1", "1���");
   @SetTagValue("BINDLIST_LPCU_SET2", "��Ż��");
   $M_LPCU_SET_LM1_Q = $LPCU_SET_LM1_Q;
   $M_LPCU_SET_LM2_Q = $LPCU_SET_LM2_Q;   
}
elseif ($LPCU_SET_L == 0)
{
   @SetTagValue("BINDLIST_LPCU_SET1", "1���");
   @SetTagValue("BINDLIST_LPCU_SET2", "��Ʈ����");
   $M_LPCU_SET_LM1_Q = $LPCU_SET_LM1_Q;
   $M_LPCU_SET_LM2_Q = $LPCU_SET_LM2_Q;  
}

   $LPCU_SET_LM1_Q.address = $LPCU_SET_LM1_Q.address + 1;
   $LPCU_SET_LM2_Q.address = $LPCU_SET_LM2_Q.address + 1;

@CsvBlockGet(id, "CSV1.txt", i);
//@CsvBlockSet(id, "CSV", i);
}
@sprintf(buf, "C:\\%4d%02d%02d%02d%02d%02d.csv", @GetDateYear(),@GetDateMon(),@GetDateDay(),@GetTimeHour(),@GetTimeMin(),@GetTimeSec());
@SetTagValue("filename", buf);
@CsvBlockSave(id, $filename);
$LPCU_SET_L.address = 220;
$LPCU_SET_LM1_Q.address = 221;
$LPCU_SET_LM2_Q.address = 222; 
@CsvBlockFree(id);

@DialogSetFilter("Csv files|*.csv|");

retn = @DialogFileOpen($filename);

if(retn == 1) {

   @CsvBlockFree($ID);

   $ID = @CsvBlockLoad($filename, 3, 220);

   @CsvBlockSet($ID, "CSV.txt", 0);

   Number = 0;

}

