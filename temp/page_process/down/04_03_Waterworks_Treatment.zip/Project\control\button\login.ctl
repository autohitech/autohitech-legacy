Description, ,
ScanTime, 1,
Data, char, name, 100,
Data, char, pass, 100,
Programm,
@EditBoxGetText("ebID", name, 20);
@EditBoxGetText("ebPW", pass, 20);
@LogInUserPass(name, pass);
@CloseModule();
@LoadModule("module_02.mod");
$PAGE = 2;

