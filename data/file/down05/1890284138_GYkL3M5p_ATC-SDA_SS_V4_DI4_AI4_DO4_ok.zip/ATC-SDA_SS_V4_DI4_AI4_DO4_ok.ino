/*
// **************************************************************************
// ATC-SDA_V4.0     SP0 : Modbus Slave     SP1 : Modbus Slave
// **************************************************************************
* SM : DI4 -- AI4 -- DO4
* 
* Communication 1: Modbus Slave  (SP00)
* Communication 2: Modbus Slave (SP01)
* 
* Creation Date : 2019-07-17
* Programer : Hosoon, Lee
* **************************************************************************
* Pin Assignment
* 
* Button S/W : D04(SW1), D11(SW2), D12(SW3), D13(SW4) 
* SM 0 : A00, A01, D07, D08
* SM 1 : A02, A03, A06, A07
* SM 2 : D10, D09, D06, D05
* 
* ***************************************************************************
* 
* Modbus Address Map 
* 
* 40000 : SM00 (IX00 ~ IX03)
* 40001 : SM01 (IW10)
* 40002 : SM01 (IW11)
* 40003 : SM01 (IW12)
* 40004 : SM01 (IW13)
* 40005 : SM02 (QX20 ~ QX23)

* 40012 : SP00 baud 통신속도(0:4800, 1:9600, 2:19200, 3:38400)
* 40013 : SP01 baud 통신속도(0:4800, 1:9600, 2:19200, 3:38400)
* 40014 : Reserve
* 40015 : Bit write  b0(MX08) ~ b15(MX15)  
// **************************************************************************
*/


//================================================================================
//  S  T  A  R  T              DI4 - AI4 - DO4 
//================================================================================
#include <ModbusRtu.h>
#include <EEPROM.h>
#include <SimpleTimer.h>
#include <SoftwareSerial.h> 
#include "U8glib.h"


byte id0, id1;              // 통신 id번호
byte baud0, baud1;          // 통신속도(0,1,2...)
word baudrate0, baudrate1;  // 통신속도(4800,9600,19200...)

//변수선언
bool IX00, IX01, IX02, IX03;          // 디지털 입력변수(SM0)
int IW10, IW11, IW12, IW13;        // 아날로그 입력변수(SM1)
bool QX20, QX21, QX22, QX23;   // 디지털 출력변수(SM2)

bool MX00, MX01, MX02, MX03;   // 내부변수
bool MX04, MX05, MX06, MX07;   // 내부변수
bool MX08, MX09, MX10, MX11;   // 내부변수
bool MX12, MX13, MX14, MX15;   // 내부변수
bool MX16, MX17, MX18, MX19;   // 내부변수
bool MX20, MX21, MX22, MX23;   // 내부변수

byte i, do_no=0;

int timer001,timer002;      // 타이머 진행시간 변수
boolean t001,t002;          // 타이머 동작 변수

//모드버스 변수
u16 _D[30];                 // modbus registor array

//화면전환 변수
byte flag = 0;
bool sw = 0;
char i0[2], i1[2], i2[2];

//OLED 선택
U8GLIB_SSD1306_128X64 u8g(U8G_I2C_OPT_NONE|U8G_I2C_OPT_DEV_0);  // I2C / TWI 

//모드버스 마스터, 슬레이브의 오브젝트 생성
Modbus slave0(id0,0,0);
Modbus slave1(id1);         //SoftwareSerial //(1~247 slave) 

//소프트웨어 시리얼 열기
SoftwareSerial mySerial(2,3);

// 타이머 오브젝트 생성
SimpleTimer timer;


//키 정의
int KeyBack =4;
int KeyPrev = 11;
int KeyNext = 12;
int KeySelect = 13;
int menu = 1, sub_menu=0;

int SM00 = A0, SM01 = A1, SM02 = 7, SM03 = 8;     // SM0 핀 정의
int SM10 = A2, SM11 = A3,SM12 = A6, SM13 = A7; // SM1 핀 정의
int SM20 = 10, SM21 = 9, SM22 = 6, SM23 = 5;       // SM2 핀 정의

void fn();          //타이머 및 기타변수

//==============================================================
//                     SETUP
//==============================================================
void setup() {
  
//id 및 baudrate 불러오기
  EEPROM.get(0,id0);
  EEPROM.get(2,baud0);
  EEPROM.get(4,id1);
  EEPROM.get(6,baud1);

//SP00 통신속도
  if (baud0 == 0) baudrate0 = 4800;
  if (baud0 == 1) baudrate0 = 9600;
  if (baud0 == 2) baudrate0 = 19200;    
  if (baud0 == 3) baudrate0 = 38400; 
  _D[12] = baud0;

//SP01 통신속도
  if (baud1 == 0) baudrate1 = 4800;
  if (baud1 == 1) baudrate1 = 9600;
  if (baud1 == 2) baudrate1 = 19200;    
  if (baud1 == 3) baudrate1 = 38400;
  _D[13] = baud1;

//모드버스 슬레이브의 ID변경
  slave0.setID(id0);
  slave1.setID(id1);
  
// 화면 180도 회전
  u8g.setRot180(); 
  delay(300);
  draw();
   
// 입출력 핀 정의
  pinMode(KeyBack, INPUT);          // set pin to input with pullup  
  pinMode(KeyPrev, INPUT);           // set pin to input with pullup
  pinMode(KeyNext, INPUT);           // set pin to input with pullup
  pinMode(KeySelect, INPUT);        // set pin to input with pullup

// SM0(DI4) 디지털 입력핀 정의
  pinMode(SM00, INPUT);
  pinMode(SM01, INPUT);
  pinMode(SM02, INPUT);
  pinMode(SM03, INPUT);

// SM2(DO4) 디지털 출력핀 정의
  pinMode(SM20, OUTPUT);
  pinMode(SM21, OUTPUT);
  pinMode(SM22, OUTPUT);
  pinMode(SM23, OUTPUT);
 
// 통신속도 및 타임아웃 시간 설정
  slave0.begin( baudrate0 );            //  RX0, TX0
  slave1.begin(&mySerial, baudrate1 );  // SoftWareSerial  

// 타이머 오브젝트 시간 설정
  timer.setInterval(100,fn);
}

//==============================================================
//                     LOOP
//==============================================================
void loop() {

//SM0(DI4) 디지털 입력 읽기
  IX00 = digitalRead(SM00);
  IX01 = digitalRead(SM01);
  IX02 = digitalRead(SM02);
  IX03 = digitalRead(SM03);
  
// SM1(AI4) 아날로그 입력 읽기
    IW10 = map(analogRead(SM10),0,1000,0,1000);
    IW11 = map(analogRead(SM11),0,1000,0,1000);
    IW12 = map(analogRead(SM12),0,1000,0,1000);
    IW13 = map(analogRead(SM13),0,1000,0,1000);

// Serial(SP00 / SP01) 통신 입력 읽기
    MX08 = _D[15] & 0x0001;  // QX20 = ON
    MX09 = _D[15] & 0x0002;  // QX20 = OFF 
    MX10 = _D[15] & 0x0004;  // QX21 = ON
    MX11 = _D[15] & 0x0008;  // QX21 = OFF
    MX12 = _D[15] & 0x0010;  // QX22 = ON
    MX13 = _D[15] & 0x0020;  // QX22 = OFF 
    MX14 = _D[15] & 0x0040;  // QX23 = ON
    MX15 = _D[15] & 0x0080;  // QX23 = OFF

//----------------------------------------------------------------------------------------------------------------------
//    L O G I C      P R O G R A M     S T A R T 
//----------------------------------------------------------------------------------------------------------------------
  //SM2
  if (MX00== 1 || MX08 == 1 ) { QX20 = 1; MX00 = 0; MX08 = 0;}
  if (MX01== 1 || MX09 == 1 ) { QX20 = 0; MX01 = 0; MX09 = 0;}
    
  if (MX02== 1 || MX10 == 1 ) { QX21 = 1; MX02 = 0; MX10 = 0;}
  if (MX03== 1 || MX11 == 1 ) { QX21 = 0; MX03 = 0; MX11 = 0;}

  if (MX04== 1 || MX12 == 1 ) { QX22 = 1; MX04 = 0; MX12 = 0;}
  if (MX05== 1 || MX13 == 1 ) { QX22 = 0; MX05 = 0; MX13 = 0;}

  if (MX06== 1 || MX14 == 1 ) { QX23 = 1; MX06 = 0; MX14 = 0;}
  if (MX07== 1 || MX15 == 1 ) { QX23 = 0; MX07 = 0; MX15 = 0;}
//----------------------------------------------------------------------------------------------------------------------
//    L O G I C      P R O G R A M     E N D 
//----------------------------------------------------------------------------------------------------------------------

// SM2(DO4) 디지털 출력
    digitalWrite(SM20, QX20);    
    digitalWrite(SM21, QX21);
    digitalWrite(SM22, QX22);
    digitalWrite(SM23, QX23);

// 모드버스 slave 어드레스 mapping  
    _D[0] = IX00 + (IX01 * 2) + (IX02 * 4) + (IX03 * 8);
    _D[1] = IW10;
    _D[2] = IW11;
    _D[3] = IW12;
    _D[4] = IW13;
    _D[5] = QX20 + (QX21 * 2) + (QX22 * 4) + (QX23 * 8);
    
    slave0.poll( _D, 30 );
    slave1.poll( _D, 30 );
    timer.run();   

//----------------------------------------------------------------------- 
    if (flag == 0) {
      u8g.firstPage();
      do  {
        draw();
        flag = 1;
      } while( u8g.nextPage() );
    }
    else { 
      if (flag == 1) {
        if (sw == 0 && !digitalRead(KeySelect)) {
        flag = 2; sw = 1;  
        }
      }
      if (flag == 2) {
        if (!digitalRead(KeyNext)) {
          menu++;
        }
        if (!digitalRead(KeyPrev)) {
          menu--;
        }
        if (menu == 1 && sw == 0 && !digitalRead(KeySelect)) {
          flag = 3; sw = 1; sub_menu = 0;
        }
        if (menu == 2 && sw == 0 && !digitalRead(KeySelect)) {
          flag = 3; sw = 1; sub_menu = 1;
        }
        if (menu == 3 && sw == 0 && !digitalRead(KeySelect)) {
          flag = 3; sw = 1; sub_menu = 5; 
        }
        if (!digitalRead(KeyBack)) {
          flag = 0; sw = 1;  menu = 1; sub_menu = 0; do_no = 0;
        }     
      }
      if (flag == 3) {   
        if (!digitalRead(KeyBack)) {
          flag = 2; sw = 1;  menu = 1; sub_menu = 0; do_no = 0; 
        } 
      }
    }
    
// SP0, SP1 ID 및 통신속도 초기화
  if (!digitalRead(KeyBack) && !digitalRead(KeyNext) && !digitalRead(KeyPrev) && !digitalRead(KeySelect))
     {
      EEPROM.put(0,1);
      EEPROM.put(2,2);
      EEPROM.put(4,1);
      EEPROM.put(6,2);
     }
//--------------------------------------------------------------------
    if (sw == 0 && flag == 2 ) {   
      u8g.firstPage();
      do {
        updateMenu(); 
      } while( u8g.nextPage() );
    }

    if (sw == 0 && flag == 3) {
      u8g.firstPage();
      do  {
        executeAction();  
      } while( u8g.nextPage() );
    }
//--------------------------------------------------------------------
//id0 설정
    if (flag == 3 && sub_menu == 1) {
      if (!digitalRead(KeyPrev)) {id0++;}
      if (!digitalRead(KeyNext)) {id0--;}
      if (sw == 0 && !digitalRead(KeySelect)) {
        sub_menu++;
        EEPROM.put(0,id0); 
        sw = 1;
      }    
      u8g.firstPage();
      do  {
        executeAction(); 
      } while( u8g.nextPage() );
    }
    
//baudrate0 설정
    if (flag == 3 && sub_menu == 2) {
      if (!digitalRead(KeyPrev)) {
        if (baudrate0 < 38400) {baudrate0 *= 2;}
      }
      if (!digitalRead(KeyNext)) {
        if (baudrate0 > 4800) {baudrate0 /= 2;}
      }
      if (sw == 0 && !digitalRead(KeySelect)) {
        sub_menu++;
        sw = 1; 
        if (baudrate0 == 4800) baud0 = 0; EEPROM.put(2,baud0); 
        if (baudrate0 == 9600) baud0 = 1; EEPROM.put(2,baud0); 
        if (baudrate0 == 19200) baud0 = 2; EEPROM.put(2,baud0); 
        if (baudrate0 == 38400) baud0 = 3; EEPROM.put(2,baud0); 
      }
      u8g.firstPage();
      do  {
        executeAction(); 
      } while( u8g.nextPage() );
    }

//--------------------------------------------------------------------
//id1 설정
    if (flag == 3 && sub_menu == 3) {
      if (!digitalRead(KeyPrev)) {id1++;}
      if (!digitalRead(KeyNext)) {id1--;}
      if (sw == 0 && !digitalRead(KeySelect)) {
        sub_menu++;
        EEPROM.put(4,id1); 
        sw = 1;
      }    
      u8g.firstPage();
      do  {
        executeAction(); 
      } while( u8g.nextPage() );
    }
    
//baudrate1 설정
    if (flag == 3 && sub_menu == 4) {
      if (!digitalRead(KeyPrev)) {
        if (baudrate1 < 38400) {baudrate1 *= 2;}
      }
      if (!digitalRead(KeyNext)) {
        if (baudrate1 > 4800) {baudrate1 /= 2;}
      }
      if (sw == 0 && !digitalRead(KeySelect)) {
        sub_menu = 1;
        sw = 1; 
        if (baudrate1 == 4800) baud1 = 0; EEPROM.put(6,baud1); 
        if (baudrate1 == 9600) baud1 = 1; EEPROM.put(6,baud1); 
        if (baudrate1 == 19200) baud1 = 2; EEPROM.put(6,baud1); 
        if (baudrate1 == 38400) baud1 = 3; EEPROM.put(6,baud1); 
      }
      u8g.firstPage();
      do  {
        executeAction(); 
      } while( u8g.nextPage() );
    }

//DO 강제출력 
    if (flag == 3 && sub_menu == 5) {
      if (!digitalRead(KeyPrev) && do_no < 3) { do_no++; }
      if (!digitalRead(KeyNext) && do_no > 0) { do_no--; }
      if (sw == 0 && !digitalRead(KeySelect)) {
        
         //SM2
         if (do_no == 0 && QX20 == 0) {MX00 = 1;} 
         if (do_no == 0 && QX20 == 1) {MX01 = 1;}         
         if (do_no == 1 && QX21 == 0) {MX02 = 1;} 
         if (do_no == 1 && QX21 == 1) {MX03 = 1;}   
         if (do_no == 2 && QX22 == 0) {MX04 = 1;} 
         if (do_no == 2 && QX22 == 1) {MX05 = 1;}             
         if (do_no == 3 && QX23 == 0) {MX06 = 1;} 
         if (do_no == 3 && QX23 == 1) {MX07 = 1;}
      }   
      u8g.firstPage();
      do  {
        executeAction(); 
      } while( u8g.nextPage() );
    }


//--------------------------------------------------------------------  
    if (digitalRead(KeySelect)) {
      sw = 0;    
    }
    delay(10);
  page_return();
}
//==============================================================
//                     DRAW
//==============================================================
void draw() {
  u8g.setFont(u8g_font_10x20);
  u8g.drawStr( 5, 22, F("ATC-SDA SS"));
  u8g.drawStr( 0, 42, F("[DI4-AI4-DO4]"));
  u8g.setFont(u8g_font_6x13);
  u8g.drawStr( 28, 59, F("A-Technology"));
}

//==============================================================
//                     UPDATE
//==============================================================
void updateMenu() { 
  switch (menu) {  
    case 0:
      menu = 1;
      break;     
    case 1:
      u8g.setFont(u8g_font_10x20);
      u8g.drawStr( 10, 20, F("->STATUS"));
      u8g.drawStr( 10, 40, F("  SETUP"));
      u8g.drawStr( 10, 60, F("  FORCE DO"));
      break;
     
    case 2:
      u8g.setFont(u8g_font_10x20);
      u8g.drawStr( 10, 20, F("  STATUS"));
      u8g.drawStr( 10, 40, F("->SETUP"));
      u8g.drawStr( 10, 60, F("  FORCE DO"));     
      break;
   
    case 3:
      u8g.setFont(u8g_font_10x20);
      u8g.drawStr( 10, 20, F("  STATUS"));
      u8g.drawStr( 10, 40, F("  SETUP"));
      u8g.drawStr( 10, 60, F("->FORCE DO"));      
      break;
      
    case 4:
      menu = 3;
      break;  
  }  
}

//==============================================================
//                     EXECUTE ACTION
//==============================================================
void executeAction() {
  switch (sub_menu) {
    case 0:
      action1();
      break;
    case 1:
      action2();
      break;     
    case 2:
      action3();
      break;     
    case 3:
      action4();
      break;       
    case 4:
      action5();
      break;
    case 5:
      action6();
      break; 
  }
}

//==============================================================
//                     ACTION1
//==============================================================
void action1() {
  u8g.setFont(u8g_font_10x20);
  u8g.drawStr( 10, 20, F("STATUS"));
  u8g.drawHLine(10, 20, 120);
  u8g.setFont(u8g_font_6x13);     
 
  sprintf(i0,"DI %d  %d  %d  %d", IX00, IX01, IX02, IX03);
  u8g.drawStr( 4, 34, i0);
  
  sprintf(i1,"AI %03d %03d %03d %03d", IW10, IW11, IW12, IW13);
  u8g.drawStr( 4, 46, i1);
  
  sprintf(i2,"DO %d  %d  %d  %d", QX20, QX21, QX22, QX23);
  u8g.drawStr( 4, 58, i2); 
}

//==============================================================
//                     ACTION2
//==============================================================
void action2() {
  u8g.setFont(u8g_font_10x20);
  u8g.drawStr( 10, 20, F("SETUP"));
  u8g.drawHLine(10, 20, 120);
  u8g.setFont(u8g_font_6x13);   
  
  sprintf(i0,"ID0 = %d", id0);  
  u8g.drawStr( 4, 34, i0);
}

//==============================================================
//                     ACTION3
//==============================================================
void action3() {
  u8g.setFont(u8g_font_10x20);
  u8g.drawStr( 10, 20, F("SETUP"));
  u8g.drawHLine(10, 20, 120);
  u8g.setFont(u8g_font_6x13); 

  sprintf(i0,"BAUDRATE0 = %u", baudrate0);  
  u8g.drawStr( 4, 34, i0);
}

//==============================================================
//                     ACTION4
//==============================================================
void action4() {
  u8g.setFont(u8g_font_10x20);
  u8g.drawStr( 10, 20, F("SETUP"));
  u8g.drawHLine(10, 20, 120);
  u8g.setFont(u8g_font_6x13);   
  
  sprintf(i0,"ID1 = %d", id1);  
  u8g.drawStr( 4, 34, i0);
}

//==============================================================
//                     ACTION5
//==============================================================
void action5() {
  u8g.setFont(u8g_font_10x20);
  u8g.drawStr( 10, 20, F("SETUP"));
  u8g.drawHLine(10, 20, 120);
  u8g.setFont(u8g_font_6x13); 

  sprintf(i0,"BAUDRATE1 = %u", baudrate1);  
  u8g.drawStr( 4, 34, i0);
}

//==============================================================
//                     ACTION6
//==============================================================
void action6() {
  u8g.setFont(u8g_font_10x20);
  u8g.drawStr( 10, 20, F("FORCE DO"));
  u8g.drawHLine(10, 20, 120);
  u8g.setFont(u8g_font_6x13);
  sprintf(i0,"DO no = %d",do_no);
  u8g.drawStr( 4, 34, i0);
  sprintf(i1,"DO %d  %d  %d  %d", QX20, QX21, QX22, QX23);
  u8g.drawStr( 4, 56, i1);
}

//==============================================================
//                     PAGE RETURN
//==============================================================
//일정시간 후에 초기화면으로 복귀
void page_return(){
  if(flag > 1 && (digitalRead(KeyPrev) || digitalRead(KeyNext) || digitalRead(KeySelect))){
    t001 = 1;
    if(timer001 > 50){
      flag = 0; menu = 1; sub_menu = 0;
      do  {
        draw();
      }   while( u8g.nextPage() );
      t001 = 0;
    }
    if(!digitalRead(KeyPrev) || !digitalRead(KeyNext) || !digitalRead(KeySelect)){
      t001 = 0;
    }
  }


}

//==============================================================
//                     FN (Timer)
//==============================================================
void fn() {
  if (t001 == 1) {timer001 = timer001 + 1;}
  if (t001 == 0) {timer001 = 0;}
  if (t002 == 1) {timer002 = timer002 + 1;}
  if (t002 == 0) {timer002 = 0;}
}
//================================================================================
//  E  N  D            DI4 - AI4 - DO4 
//================================================================================
